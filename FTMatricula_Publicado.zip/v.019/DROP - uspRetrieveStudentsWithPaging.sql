USE [matrifunDB]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[uspRetrieveStudentsWithPaging]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [uspRetrieveStudentsWithPaging]
GO
