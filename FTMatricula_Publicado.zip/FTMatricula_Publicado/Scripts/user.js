﻿var FTMatricula = FTMatricula || {};

FTMatricula.user = (function () {
	var options = {};

	//initialize function
	var initialize = function (opts) {
		$.extend(options, opts);
		addRoles();
		loadPeriodo();
		checkAdminSchool();
	};

	var addRoles = function () {
		$('#btnSaveRoles').off('click.btnSaveRoles').on('click.btnSaveRoles', function () {
			var listRoles = [];

			$('#tbody').find('tr').each(function (i, value) {
				var roles = {};
				var $tr = $(this);
				var $spanRole = $tr.find('span');

				roles.RoleName = $spanRole.attr('role');
				roles.Role = $spanRole.text();
				roles.IsActive = $tr.find('input:checkbox').is(':checked');

				listRoles.push(roles);
			});
			$.bAjax({
				url: options.urlSave,
				async: false,
				data: { userName: options.username, listRoles: JSON.stringify(listRoles) },
				ajaxSuccess: function (response) {
					if (response) {
						$('#msgArea').html('Roles Salvados Exitosamente').fadeIn('100').fadeOut('190000');
					}
				}
			});

			$('form').submit();

			return false;
		});
	};

	var loadPeriodo = function () {
		var tr = [];
		var listRoles = $.parseJSON(options.listRoles.replace(/&quot;/ig, '"'));

		for (i = 0; i < listRoles.length; i++) {
			if (listRoles[i].RoleName == 'ROLE_SCHOOL_ADMIN' && listRoles[i].IsActive)
				$('#schoolSection').fadeIn();

			tr.push('<tr><td><input type="checkbox" id="chk_' + listRoles[i].RoleName + '" ');
			tr.push(listRoles[i].IsActive ? 'checked="checked"' : '');
			tr.push(' />');
			tr.push('</td><td><span role="' + listRoles[i].RoleName + '">');
			tr.push(listRoles[i].Role);
			tr.push('</span></td>');
			tr.push('</tr>');
		}
		$('#tbody').html(tr.join(''));
	};

	var checkAdminSchool = function () {
		$('#tbody').off('click.chk_ROLE_SCHOOL_ADMIN').on('click.chk_ROLE_SCHOOL_ADMIN', '#chk_ROLE_SCHOOL_ADMIN', function () {
			if ($(this).is(':checked')) {
				$('#schoolSection').fadeIn();
				$('#RoleName').val('ROLE_SCHOOL_ADMIN');
			}
			else {
				$('#schoolSection').fadeOut();				
				$('#RoleName').val('');
			}
		});
	};

	//Public methods
	return {
		init: initialize
	};
})();

