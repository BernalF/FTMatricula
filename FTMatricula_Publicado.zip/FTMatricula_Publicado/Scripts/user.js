﻿var FTMatricula = FTMatricula || {};

FTMatricula.user = (function () {
    var options = {};

    //initialize function
    var initialize = function (opts) {
        $.extend(options, opts);
        addRoles();
        loadRoles();
        loadSchools();
        checkAdminSchool();
    };

    var addRoles = function () {
        $('#btnSaveRoles').off('click.btnSaveRoles').on('click.btnSaveRoles', function () {
            var listRoles = [];
            var listSchools = [];

            $('#rtbody').find('tr').each(function (i, value) {
                var roles = {};
                var $tr = $(this);
                var $spanRole = $tr.find('span');

                roles.RoleName = $spanRole.attr('role');
                roles.Role = $spanRole.text();
                roles.IsActive = $tr.find('input:checkbox').is(':checked');

                listRoles.push(roles);
            });

            $('#stbody').find('tr').each(function (i, value) {
                var schools = {};
                var $tr = $(this);
                var $spanRole = $tr.find('span');

                schools.SchoolId = $spanRole.attr('sid');
                schools.IsActive = $tr.find('input:checkbox').is(':checked');

                listSchools.push(schools);
            });

            $.bAjax({
                url: options.urlSave,
                async: false,
                data: {
                    userName: options.username,
                    listRoles: JSON.stringify(listRoles),
                    listSchools: JSON.stringify(listSchools),
                    isAdmin: $('#RoleName').val() != '' ? true : false 
                },
                ajaxSuccess: function (response) {
                    if (response) {
                        $('#msgArea').html('Información Salvada Exitosamente').fadeIn('100').fadeOut('190000');
                    }
                }
            });

            return false;
        });
    };

    var loadRoles = function () {
        var tr = [];
        var listRoles = $.parseJSON(options.listRoles.replace(/&quot;/ig, '"'));

        for (i = 0; i < listRoles.length; i++) {
            if (listRoles[i].RoleName == 'ROLE_SCHOOL_ADMIN' && listRoles[i].IsActive)
                $('#schoolSection').fadeIn();

            tr.push('<tr><td><input type="checkbox" id="chk_' + listRoles[i].RoleName + '" ');
            tr.push(listRoles[i].IsActive ? 'checked="checked"' : '');
            tr.push(' />');
            tr.push('</td><td><span role="' + listRoles[i].RoleName + '">');
            tr.push(listRoles[i].Role);
            tr.push('</span></td>');
            tr.push('</tr>');
        }
        $('#rtbody').html(tr.join(''));
    };

    var loadSchools = function () {
        var tr = [];
        var listSchools = $.parseJSON(options.listSchools.replace(/&quot;/ig, '"'));

        for (i = 0; i < listSchools.length; i++) {
            tr.push('<tr><td><input type="checkbox" id="chk_' + listSchools[i].Name.replace(/\s/g, '') + '" ');
            tr.push(listSchools[i].IsActive ? 'checked="checked"' : '');
            tr.push(' />');
            tr.push('</td><td><span sid="' + listSchools[i].SchoolId + '">');
            tr.push(listSchools[i].Name);
            tr.push('</span></td>');
            tr.push('</tr>');
        }
        $('#stbody').html(tr.join(''));
    };

    var checkAdminSchool = function () {
        $('#rtbody').off('click.chk_ROLE_SCHOOL_ADMIN').on('click.chk_ROLE_SCHOOL_ADMIN', '#chk_ROLE_SCHOOL_ADMIN', function () {
            if ($(this).is(':checked')) {
                $('#schoolSection').fadeIn();
                $('#RoleName').val('ROLE_SCHOOL_ADMIN');
            }
            else {
                $('#schoolSection').fadeOut();
                $('#RoleName').val('');
            }
        });
    };

    //Public methods
    return {
        init: initialize
    };
})();

