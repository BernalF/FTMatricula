﻿var FTMatricula = FTMatricula || {};

FTMatricula.modality = (function () {
    var options = {};
    var listPeriod = { Period: [] };

    //initialize function
    var initialize = function (opts) {
        $.extend(options, opts);
        addPeriodo();
        delPeriodo();
        if (options.view == 'edit')
            loadPeriodo();
    };

    var addPeriodo = function () {
        $('#addPbutton').off('click.addPbutton').on('click.addPbutton', function () {
            var tr = [];
            var $PeriodoVal = $('#txtPeriodo');
            var $CodPeriodoVal = $('#txtCodPeriodo');

            if ($PeriodoVal.val() && $CodPeriodoVal.val()) {

                tr.push('<tr><td><span codigo="">');
                tr.push($CodPeriodoVal.val());
                tr.push('</span></td><td><span periodo="">');
                tr.push($PeriodoVal.val());
                tr.push('</span></td><td><a href="#" del="" class="delButton"></a></td></tr>');
                $('#tbody').append(tr.join(''));

                listPeriod.Period.push({
                    Code: $CodPeriodoVal.val(),
                    Description: $PeriodoVal.val()
                });

                $('#ListPeriodos').val(JSON.stringify(listPeriod.Period));

                $PeriodoVal.val('');
                $CodPeriodoVal.val('');
                $('.errorsSpace').find('ul').html('').hide();

            } else {
                $('.errorsSpace').find('ul').html('<li>No puede dejar campos en blanco').show();
            }
            return false;
        });
    };

    var delPeriodo = function () {
        $('#tPeriodo').off('click.tPeriodo', 'a[del]').on('click.tPeriodo', 'a[del]', function (e) {
            e.preventDefault();
            $(this).closest('tr').remove();

            findAndRemove(listPeriod.Period,
                'Code',
                'Description',
                $(this).closest('tr').find('span[codigo]').text(),
                $(this).closest('tr').find('span[periodo]').text());

            $('#ListPeriodos').val(JSON.stringify(listPeriod.Period));

            e.stopPropagation();
        });
    };

    var findAndRemove = function (array, property1, property2, value1, value2) {
        $.each(array, function (index, result) {
            if (result[property1] == value1 && result[property2] == value2) {
                array.splice(index, 1);
                return false;
            }
        });
    };

    var loadPeriodo = function () {
        var tr = [];
        listPeriod.Period = $.parseJSON($('#ListPeriodos').val());

        for (i = 0; i < listPeriod.Period.length; i++) {
            tr.push('<tr><td><span codigo="">');
            tr.push(listPeriod.Period[i].Code);
            tr.push('</span></td><td><span periodo="">');
            tr.push(listPeriod.Period[i].Description);
            tr.push('</span></td><td><a href="#" del="" class="delButton"></a></td></tr>');
        }
        $('#tbody').html(tr.join(''));
    };

    //Public methods
    return {
        init: initialize
    };
})();

