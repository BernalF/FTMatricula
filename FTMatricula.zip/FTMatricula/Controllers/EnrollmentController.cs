﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FTMatricula.Controllers
{
    public class EnrollmentController : Controller
    {
        //
        // GET: /Enrollment/

        public ActionResult Index()
        {
            return View();
        }

    }
}
