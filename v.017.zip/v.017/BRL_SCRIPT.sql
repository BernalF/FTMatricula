USE matrifunDB
GO

UPDATE dbo.Modality
SET code = UPPER(SUBSTRING(name,1,3))