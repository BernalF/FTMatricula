ALTER TABLE dbo.[Plan] ADD	ModalityID uniqueidentifier NULL
GO
ALTER TABLE [dbo].[Plan]  WITH CHECK ADD  CONSTRAINT [FK_Plan_Modality] FOREIGN KEY([ModalityID])
REFERENCES [dbo].[Modality] ([ModalityID])
GO
----------  drop period
ALTER TABLE [dbo].[Modality] DROP COLUMN Period
---------- add scheme
ALTER TABLE dbo.[Scheme] ADD Code varchar(50) NULL
GO