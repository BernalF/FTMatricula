CREATE TABLE dbo.Period
	(
	PeriodID uniqueidentifier NOT NULL,
	[Description] varchar(200) NOT NULL,
	ModalityID uniqueidentifier NOT NULL,
	InsertDate datetime NULL,
	InsertUserID uniqueidentifier NULL,
	ModifyDate datetime NULL,
	ModifyUserID uniqueidentifier NULL,
	ipAddress varchar(200) NULL
	)  ON [PRIMARY]
GO
ALTER TABLE dbo.Period ADD CONSTRAINT
	PK_Period PRIMARY KEY CLUSTERED 
	(
		PeriodID
	) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

GO
ALTER TABLE [dbo].[Period]  WITH CHECK ADD  CONSTRAINT [FK_Period_Modality] FOREIGN KEY([ModalityID])
REFERENCES [dbo].[Modality] ([ModalityID])
GO




---------------FK PeriodID from Enrollment---------

ALTER TABLE dbo.Enrollment ADD    PeriodID uniqueidentifier NULL
GO
ALTER TABLE [dbo].Enrollment  WITH CHECK ADD  CONSTRAINT [FK_Enrollment_Period] FOREIGN KEY([PeriodID])
REFERENCES [dbo].[Period] ([PeriodID])
GO

---------------FK PeriodID from Enrollment---------



---------------Code---------

ALTER TABLE dbo.Period ADD Code varchar(4) NULL
GO

ALTER TABLE dbo.Modality ADD Code varchar(4) NULL
GO
---------------Code---------
